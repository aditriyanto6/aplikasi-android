# Tentang Aplikasi
Khulafa Rasyidin merupakan aplikasi mobile untuk mengenal singkat tentang 4 sahabat rasullah yaitu :
* Abū Bakr aṣ-Ṣiddīq
* Umar ibn Al-Khattab
* Uthman ibn Affan
* Ali ibn Abi Talib

Aplikasi ini menggunakan 
* RecyclerView
* Halaman detail ketika salah satu item di tekan.
* style.

Aplikasi ini juga ditunjukan untuk final submission pada Kelas Belajar Membuat Aplikasi Android untuk Pemula Dicoding https://www.dicoding.com/academies/51/tutorials/1247

Informasi pada aplikasi ini bersumber dari wikipedia indonesia https://id.wikipedia.org

![alt text](https://raw.githubusercontent.com/muhrizky/KhulafaRasyidin/master/sertif%20android%20pemula.png)
